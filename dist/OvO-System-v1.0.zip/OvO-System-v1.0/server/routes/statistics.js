/**
 * 统计与报表路由
 * GET /api/statistics/dashboard         - 仪表盘概览
 * GET /api/statistics/low-stock         - 低库存预警
 * GET /api/statistics/trends            - 出入库趋势（折线图）
 * GET /api/statistics/inventory-report  - 库存报表
 * GET /api/statistics/movement-report   - 出入库流水报表
 * GET /api/statistics/shipment-report   - 发货统计报表
 * GET /api/statistics/category-stock    - 分类库存占比（饼图）
 * GET /api/statistics/top-materials     - 物料排行（出库最多/库存价值最高）
 * GET /api/statistics/warehouse-compare - 仓库库存对比
 */

const express = require('express');
const { getDB } = require('../db/database');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

// ============================================
// 辅助函数
// ============================================

/**
 * 生成日期序列 [startDate ... endDate]
 */
function generateDateRange(startDate, endDate) {
    const dates = [];
    const current = new Date(startDate);
    const end = new Date(endDate);
    while (current <= end) {
        dates.push(current.toISOString().split('T')[0]);
        current.setDate(current.getDate() + 1);
    }
    return dates;
}

/**
 * 解析通用日期范围参数
 * ?range=7d | 30d | 90d | custom&start=YYYY-MM-DD&end=YYYY-MM-DD
 */
function parseDateRange(query) {
    const range = query.range || '30d';
    let endDate = new Date();
    let startDate = new Date();

    if (range === 'custom' && query.start && query.end) {
        startDate = new Date(query.start);
        endDate = new Date(query.end);
    } else {
        const days = parseInt(range) || 30;
        startDate.setDate(endDate.getDate() - days + 1);
    }

    return {
        start: startDate.toISOString().split('T')[0],
        end: endDate.toISOString().split('T')[0]
    };
}


// ============================================
// GET /api/statistics/dashboard
// 仪表盘概览数据
// ============================================
router.get('/dashboard', (req, res) => {
    const db = getDB();

    const materialCount = db.prepare(
        'SELECT COUNT(*) as cnt FROM materials WHERE is_active = 1'
    ).get().cnt;

    const warehouseCount = db.prepare(
        'SELECT COUNT(*) as cnt FROM warehouses WHERE is_active = 1'
    ).get().cnt;

    const pendingShipments = db.prepare(
        "SELECT COUNT(*) as cnt FROM shipments WHERE status IN ('pending', 'confirmed')"
    ).get().cnt;

    const lowStockCount = db.prepare(`
        SELECT COUNT(DISTINCT m.id) as cnt
        FROM materials m
        JOIN inventory i ON m.id = i.material_id
        WHERE m.is_active = 1 AND m.min_stock > 0
        GROUP BY m.id
        HAVING SUM(i.quantity) <= m.min_stock
    `).all().length;

    const todayIn = db.prepare(`
        SELECT COALESCE(SUM(quantity), 0) as total
        FROM stock_movements
        WHERE type = 'in' AND date(created_at) = date('now', 'localtime')
    `).get().total;

    const todayOut = db.prepare(`
        SELECT COALESCE(SUM(quantity), 0) as total
        FROM stock_movements
        WHERE type = 'out' AND date(created_at) = date('now', 'localtime')
    `).get().total;

    const totalValue = db.prepare(`
        SELECT COALESCE(SUM(i.quantity * m.cost_price), 0) as total
        FROM inventory i
        JOIN materials m ON i.material_id = m.id
        WHERE i.quantity > 0
    `).get().total;

    const recentLogs = db.prepare(`
        SELECT ol.*, u.display_name as user_name
        FROM operation_logs ol
        LEFT JOIN users u ON ol.user_id = u.id
        ORDER BY ol.created_at DESC
        LIMIT 5
    `).all();

    res.json({
        success: true,
        data: {
            materialCount, warehouseCount, pendingShipments, lowStockCount,
            todayIn, todayOut, totalValue, recentLogs
        }
    });
});


// ============================================
// GET /api/statistics/low-stock
// 低库存预警明细
// ============================================
router.get('/low-stock', (req, res) => {
    const db = getDB();

    const items = db.prepare(`
        SELECT m.id, m.code, m.name, m.unit, m.min_stock, m.supplier,
               COALESCE(SUM(i.quantity), 0) as total_stock,
               m.min_stock - COALESCE(SUM(i.quantity), 0) as shortage
        FROM materials m
        LEFT JOIN inventory i ON m.id = i.material_id
        WHERE m.is_active = 1 AND m.min_stock > 0
        GROUP BY m.id
        HAVING total_stock <= m.min_stock
        ORDER BY shortage DESC
    `).all();

    res.json({ success: true, data: { items, count: items.length } });
});


// ============================================
// GET /api/statistics/trends
// 出入库趋势（按天聚合，折线图数据）
// ============================================
router.get('/trends', (req, res) => {
    const db = getDB();
    const { start, end } = parseDateRange(req.query);

    const movements = db.prepare(`
        SELECT date(created_at) as day, type,
               COALESCE(SUM(quantity), 0) as total_qty,
               COALESCE(SUM(total_price), 0) as total_amount
        FROM stock_movements
        WHERE date(created_at) BETWEEN ? AND ?
        GROUP BY day, type
        ORDER BY day
    `).all(start, end);

    // 填充完整日期序列
    const dates = generateDateRange(start, end);
    const inData = [];
    const outData = [];
    const inAmount = [];
    const outAmount = [];

    const movementMap = {};
    movements.forEach(m => {
        const key = m.day + '_' + m.type;
        movementMap[key] = m;
    });

    dates.forEach(d => {
        const inRow = movementMap[d + '_in'];
        const outRow = movementMap[d + '_out'];
        inData.push(inRow ? inRow.total_qty : 0);
        outData.push(outRow ? outRow.total_qty : 0);
        inAmount.push(inRow ? inRow.total_amount : 0);
        outAmount.push(outRow ? outRow.total_amount : 0);
    });

    res.json({
        success: true,
        data: {
            labels: dates,
            datasets: {
                inQty: inData,
                outQty: outData,
                inAmount,
                outAmount
            },
            summary: {
                totalIn: inData.reduce((a, b) => a + b, 0),
                totalOut: outData.reduce((a, b) => a + b, 0),
                totalInAmount: inAmount.reduce((a, b) => a + b, 0),
                totalOutAmount: outAmount.reduce((a, b) => a + b, 0)
            }
        }
    });
});


// ============================================
// GET /api/statistics/inventory-report
// 库存报表（每种物料在各仓库的库存详情）
// ============================================
router.get('/inventory-report', (req, res) => {
    const db = getDB();
    const { warehouseId, categoryId, search } = req.query;

    let sql = `
        SELECT m.id, m.code, m.name, m.unit, m.spec, m.category_id,
               c.name as category_name, m.cost_price, m.sale_price,
               m.min_stock, m.supplier,
               w.id as warehouse_id, w.name as warehouse_name,
               COALESCE(i.quantity, 0) as quantity
        FROM materials m
        LEFT JOIN categories c ON m.category_id = c.id
        CROSS JOIN warehouses w
        LEFT JOIN inventory i ON m.id = i.material_id AND w.id = i.warehouse_id
        WHERE m.is_active = 1 AND w.is_active = 1
    `;
    const params = [];

    if (warehouseId) { sql += ' AND w.id = ?'; params.push(warehouseId); }
    if (categoryId) { sql += ' AND m.category_id = ?'; params.push(categoryId); }
    if (search) { sql += ' AND (m.name LIKE ? OR m.code LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }

    sql += ' ORDER BY m.code, w.name';

    const rows = db.prepare(sql).all(...params);

    // 聚合按物料
    const materialMap = {};
    rows.forEach(r => {
        if (!materialMap[r.id]) {
            materialMap[r.id] = {
                id: r.id, code: r.code, name: r.name, unit: r.unit, spec: r.spec,
                category_name: r.category_name, cost_price: r.cost_price,
                sale_price: r.sale_price, min_stock: r.min_stock, supplier: r.supplier,
                total_stock: 0, total_value: 0,
                warehouses: []
            };
        }
        materialMap[r.id].warehouses.push({
            warehouse_id: r.warehouse_id, warehouse_name: r.warehouse_name, quantity: r.quantity
        });
        materialMap[r.id].total_stock += r.quantity;
        materialMap[r.id].total_value += r.quantity * r.cost_price;
    });

    const items = Object.values(materialMap);
    const grandTotalQty = items.reduce((s, i) => s + i.total_stock, 0);
    const grandTotalValue = items.reduce((s, i) => s + i.total_value, 0);

    res.json({
        success: true,
        data: {
            items,
            summary: { totalMaterials: items.length, totalQuantity: grandTotalQty, totalValue: grandTotalValue }
        }
    });
});


// ============================================
// GET /api/statistics/movement-report
// 出入库流水报表
// ============================================
router.get('/movement-report', (req, res) => {
    const db = getDB();
    const { start, end } = parseDateRange(req.query);
    const { type, warehouseId, materialId } = req.query;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 50;

    let whereClauses = ['date(sm.created_at) BETWEEN ? AND ?'];
    const params = [start, end];

    if (type) { whereClauses.push('sm.type = ?'); params.push(type); }
    if (warehouseId) { whereClauses.push('sm.warehouse_id = ?'); params.push(warehouseId); }
    if (materialId) { whereClauses.push('sm.material_id = ?'); params.push(materialId); }

    const whereSQL = whereClauses.join(' AND ');

    const total = db.prepare(`
        SELECT COUNT(*) as cnt FROM stock_movements sm WHERE ${whereSQL}
    `).get(...params).cnt;

    const items = db.prepare(`
        SELECT sm.*, m.name as material_name, m.code as material_code, m.unit,
               w.name as warehouse_name, u.display_name as operator_name
        FROM stock_movements sm
        LEFT JOIN materials m ON sm.material_id = m.id
        LEFT JOIN warehouses w ON sm.warehouse_id = w.id
        LEFT JOIN users u ON sm.created_by = u.id
        WHERE ${whereSQL}
        ORDER BY sm.created_at DESC
        LIMIT ? OFFSET ?
    `).all(...params, limit, (page - 1) * limit);

    // 汇总
    const summary = db.prepare(`
        SELECT type,
               COUNT(*) as count,
               COALESCE(SUM(quantity), 0) as total_qty,
               COALESCE(SUM(total_price), 0) as total_amount
        FROM stock_movements sm
        WHERE ${whereSQL}
        GROUP BY type
    `).all(...params);

    res.json({
        success: true,
        data: {
            items,
            pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
            summary,
            dateRange: { start, end }
        }
    });
});


// ============================================
// GET /api/statistics/shipment-report
// 发货统计报表
// ============================================
router.get('/shipment-report', (req, res) => {
    const db = getDB();
    const { start, end } = parseDateRange(req.query);
    const { status } = req.query;

    let whereClauses = ['date(s.created_at) BETWEEN ? AND ?'];
    const params = [start, end];
    if (status) { whereClauses.push('s.status = ?'); params.push(status); }
    const whereSQL = whereClauses.join(' AND ');

    // 按状态汇总
    const statusSummary = db.prepare(`
        SELECT status, COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total_amount
        FROM shipments s
        WHERE ${whereSQL}
        GROUP BY status
    `).all(...params);

    // 按日汇总
    const dailySummary = db.prepare(`
        SELECT date(s.created_at) as day, COUNT(*) as count,
               COALESCE(SUM(total_amount), 0) as total_amount
        FROM shipments s
        WHERE ${whereSQL}
        GROUP BY day ORDER BY day
    `).all(...params);

    // 热销物料 TOP 10
    const topMaterials = db.prepare(`
        SELECT m.id, m.name, m.code, m.unit,
               SUM(si.quantity) as total_qty,
               SUM(si.total_price) as total_amount
        FROM shipment_items si
        JOIN shipments s ON si.shipment_id = s.id
        JOIN materials m ON si.material_id = m.id
        WHERE ${whereSQL} AND s.status != 'cancelled'
        GROUP BY m.id
        ORDER BY total_qty DESC
        LIMIT 10
    `).all(...params);

    // 客户排行 TOP 10
    const topCustomers = db.prepare(`
        SELECT customer_name, COUNT(*) as order_count,
               COALESCE(SUM(total_amount), 0) as total_amount
        FROM shipments s
        WHERE ${whereSQL} AND s.status != 'cancelled' AND customer_name IS NOT NULL AND customer_name != ''
        GROUP BY customer_name
        ORDER BY total_amount DESC
        LIMIT 10
    `).all(...params);

    // 完整日期填充
    const dates = generateDateRange(start, end);
    const dailyMap = {};
    dailySummary.forEach(d => { dailyMap[d.day] = d; });
    const dailyData = dates.map(d => ({
        day: d,
        count: dailyMap[d] ? dailyMap[d].count : 0,
        total_amount: dailyMap[d] ? dailyMap[d].total_amount : 0
    }));

    res.json({
        success: true,
        data: {
            statusSummary,
            dailyData,
            topMaterials,
            topCustomers,
            dateRange: { start, end }
        }
    });
});


// ============================================
// GET /api/statistics/category-stock
// 分类库存占比（饼图数据）
// ============================================
router.get('/category-stock', (req, res) => {
    const db = getDB();

    const items = db.prepare(`
        SELECT COALESCE(c.name, '未分类') as category_name,
               COUNT(DISTINCT m.id) as material_count,
               COALESCE(SUM(i.quantity), 0) as total_stock,
               COALESCE(SUM(i.quantity * m.cost_price), 0) as total_value
        FROM materials m
        LEFT JOIN categories c ON m.category_id = c.id
        LEFT JOIN inventory i ON m.id = i.material_id
        WHERE m.is_active = 1
        GROUP BY c.id
        ORDER BY total_value DESC
    `).all();

    res.json({ success: true, data: { items } });
});


// ============================================
// GET /api/statistics/top-materials
// 物料排行
// ============================================
router.get('/top-materials', (req, res) => {
    const db = getDB();
    const { start, end } = parseDateRange(req.query);
    const limit = parseInt(req.query.limit) || 10;

    // 出库量 TOP
    const topByOutQty = db.prepare(`
        SELECT m.id, m.name, m.code, m.unit, SUM(sm.quantity) as total_qty
        FROM stock_movements sm
        JOIN materials m ON sm.material_id = m.id
        WHERE sm.type = 'out' AND date(sm.created_at) BETWEEN ? AND ?
        GROUP BY m.id
        ORDER BY total_qty DESC
        LIMIT ?
    `).all(start, end, limit);

    // 库存价值 TOP
    const topByValue = db.prepare(`
        SELECT m.id, m.name, m.code, m.unit,
               COALESCE(SUM(i.quantity), 0) as total_stock,
               COALESCE(SUM(i.quantity * m.cost_price), 0) as total_value
        FROM materials m
        LEFT JOIN inventory i ON m.id = i.material_id
        WHERE m.is_active = 1
        GROUP BY m.id
        ORDER BY total_value DESC
        LIMIT ?
    `).all(limit);

    // 入库量 TOP
    const topByInQty = db.prepare(`
        SELECT m.id, m.name, m.code, m.unit, SUM(sm.quantity) as total_qty
        FROM stock_movements sm
        JOIN materials m ON sm.material_id = m.id
        WHERE sm.type = 'in' AND date(sm.created_at) BETWEEN ? AND ?
        GROUP BY m.id
        ORDER BY total_qty DESC
        LIMIT ?
    `).all(start, end, limit);

    res.json({
        success: true,
        data: { topByOutQty, topByValue, topByInQty, dateRange: { start, end } }
    });
});


// ============================================
// GET /api/statistics/warehouse-compare
// 仓库库存对比
// ============================================
router.get('/warehouse-compare', (req, res) => {
    const db = getDB();

    const items = db.prepare(`
        SELECT w.id, w.name,
               COUNT(DISTINCT i.material_id) as material_count,
               COALESCE(SUM(i.quantity), 0) as total_stock,
               COALESCE(SUM(i.quantity * m.cost_price), 0) as total_value
        FROM warehouses w
        LEFT JOIN inventory i ON w.id = i.warehouse_id AND i.quantity > 0
        LEFT JOIN materials m ON i.material_id = m.id
        WHERE w.is_active = 1
        GROUP BY w.id
        ORDER BY total_value DESC
    `).all();

    res.json({ success: true, data: { items } });
});


module.exports = router;
