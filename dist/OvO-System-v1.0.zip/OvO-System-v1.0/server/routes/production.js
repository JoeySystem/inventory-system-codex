/**
 * 生产工单路由
 * GET    /api/production              - 工单列表
 * GET    /api/production/:id          - 工单详情
 * POST   /api/production              - 创建工单（自动计算物料需求）
 * PUT    /api/production/:id/status   - 更新状态（开始/完成/取消）
 * PUT    /api/production/:id/progress - 更新完成数量
 * GET    /api/production/:id/check    - 物料齐套检查
 */

const express = require('express');
const { getDB } = require('../db/database');
const { requireAuth } = require('../middleware/auth');
const { requirePermission } = require('../middleware/permission');
const { logOperation } = require('../utils/logger');
const { ValidationError, NotFoundError } = require('../utils/errors');
const { addStock, deductStock, getAvailable } = require('../services/inventory');

const router = express.Router();
router.use(requireAuth);

/**
 * 生成工单号 PO-YYYYMMDD-NNN
 */
function generateOrderNo(db) {
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const last = db.prepare(
        "SELECT order_no FROM production_orders WHERE order_no LIKE ? ORDER BY order_no DESC LIMIT 1"
    ).get(`PO-${today}-%`);

    let seq = 1;
    if (last) {
        const parts = last.order_no.split('-');
        seq = parseInt(parts[2]) + 1;
    }
    return `PO-${today}-${String(seq).padStart(3, '0')}`;
}

/**
 * GET /api/production
 */
router.get('/', requirePermission('production', 'view'), (req, res) => {
    const db = getDB();
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let whereClauses = ['1=1'];
    let params = [];

    if (status) { whereClauses.push('po.status = ?'); params.push(status); }

    const whereSQL = whereClauses.join(' AND ');

    const total = db.prepare(`SELECT COUNT(*) as cnt FROM production_orders po WHERE ${whereSQL}`).get(...params).cnt;

    const orders = db.prepare(`
        SELECT po.*, s.title as sop_title, s.version as sop_version,
               w.name as warehouse_name, u.display_name as creator_name,
               om.name as output_material_name, om.unit as output_unit
        FROM production_orders po
        LEFT JOIN sops s ON po.sop_id = s.id
        LEFT JOIN warehouses w ON po.warehouse_id = w.id
        LEFT JOIN users u ON po.created_by = u.id
        LEFT JOIN materials om ON po.output_material_id = om.id
        WHERE ${whereSQL}
        ORDER BY po.created_at DESC
        LIMIT ? OFFSET ?
    `).all(...params, parseInt(limit), offset);

    res.json({
        success: true,
        data: {
            orders,
            pagination: { page: parseInt(page), limit: parseInt(limit), total, totalPages: Math.ceil(total / parseInt(limit)) }
        }
    });
});

/**
 * GET /api/production/:id
 */
router.get('/:id', requirePermission('production', 'view'), (req, res) => {
    const db = getDB();
    const order = db.prepare(`
        SELECT po.*, s.title as sop_title, s.version as sop_version, s.description as sop_description,
               w.name as warehouse_name, u.display_name as creator_name,
               om.name as output_material_name, om.unit as output_unit, om.code as output_material_code
        FROM production_orders po
        LEFT JOIN sops s ON po.sop_id = s.id
        LEFT JOIN warehouses w ON po.warehouse_id = w.id
        LEFT JOIN users u ON po.created_by = u.id
        LEFT JOIN materials om ON po.output_material_id = om.id
        WHERE po.id = ?
    `).get(req.params.id);

    if (!order) throw new NotFoundError('生产工单');

    // SOP 步骤
    const steps = db.prepare(
        'SELECT * FROM sop_steps WHERE sop_id = ? ORDER BY step_number'
    ).all(order.sop_id);

    // 物料需求清单（单件用量 × 计划数量 = 总需求）
    const materials = db.prepare(`
        SELECT sm.material_id, m.name, m.code, m.unit, m.spec,
               sm.quantity_per_unit,
               sm.quantity_per_unit * ? as total_needed,
               COALESCE((SELECT SUM(i.quantity) FROM inventory i WHERE i.material_id = sm.material_id AND i.warehouse_id = ?), 0) as available_stock,
               st.step_number, st.title as step_title
        FROM sop_materials sm
        JOIN materials m ON sm.material_id = m.id
        LEFT JOIN sop_steps st ON sm.step_id = st.id
        WHERE sm.sop_id = ?
        ORDER BY st.step_number, m.name
    `).all(order.planned_quantity, order.warehouse_id, order.sop_id);

    // 标记不足
    materials.forEach(m => {
        m.is_sufficient = m.available_stock >= m.total_needed;
        m.shortage = m.is_sufficient ? 0 : m.total_needed - m.available_stock;
    });

    const allSufficient = materials.every(m => m.is_sufficient);

    res.json({
        success: true,
        data: { order, steps, materials, allSufficient }
    });
});

/**
 * GET /api/production/:id/check
 * 物料齐套检查
 */
router.get('/:id/check', requirePermission('production', 'view'), (req, res) => {
    const db = getDB();
    const order = db.prepare('SELECT * FROM production_orders WHERE id = ?').get(req.params.id);
    if (!order) throw new NotFoundError('生产工单');

    const materials = db.prepare(`
        SELECT sm.material_id, m.name, m.code, m.unit,
               sm.quantity_per_unit,
               sm.quantity_per_unit * ? as total_needed,
               COALESCE((SELECT SUM(i.quantity) FROM inventory i WHERE i.material_id = sm.material_id AND i.warehouse_id = ?), 0) as available_stock
        FROM sop_materials sm
        JOIN materials m ON sm.material_id = m.id
        WHERE sm.sop_id = ?
    `).all(order.planned_quantity, order.warehouse_id, order.sop_id);

    const insufficient = materials.filter(m => m.available_stock < m.total_needed).map(m => ({
        ...m,
        shortage: m.total_needed - m.available_stock
    }));

    res.json({
        success: true,
        data: {
            allSufficient: insufficient.length === 0,
            total: materials.length,
            insufficientCount: insufficient.length,
            insufficient
        }
    });
});

/**
 * POST /api/production
 * 创建生产工单
 */
router.post('/', requirePermission('production', 'add'), (req, res) => {
    const db = getDB();
    const { sopId, warehouseId, plannedQuantity, outputMaterialId, notes } = req.body;

    if (!sopId) throw new ValidationError('请选择SOP');
    if (!warehouseId) throw new ValidationError('请选择仓库');
    if (!plannedQuantity || plannedQuantity <= 0) throw new ValidationError('计划数量必须大于0');

    const sop = db.prepare('SELECT * FROM sops WHERE id = ? AND is_active = 1').get(sopId);
    if (!sop) throw new NotFoundError('SOP');

    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ? AND is_active = 1').get(warehouseId);
    if (!warehouse) throw new NotFoundError('仓库');

    if (outputMaterialId) {
        const mat = db.prepare('SELECT * FROM materials WHERE id = ? AND is_active = 1').get(outputMaterialId);
        if (!mat) throw new NotFoundError('产出物料');
    }

    const doCreate = db.transaction(() => {
        const orderNo = generateOrderNo(db);
        const id = db.prepare(`
            INSERT INTO production_orders (order_no, sop_id, warehouse_id, output_material_id, planned_quantity, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(orderNo, sopId, warehouseId, outputMaterialId || null, plannedQuantity, notes || null, req.session.user.id).lastInsertRowid;
        return { id, orderNo };
    });

    const { id, orderNo } = doCreate();

    logOperation({
        userId: req.session.user.id, action: 'create', resource: 'production',
        resourceId: id, detail: `创建生产工单 ${orderNo}，SOP: ${sop.title}，计划数量: ${plannedQuantity}`, ip: req.ip
    });

    res.status(201).json({ success: true, data: { id, orderNo } });
});

/**
 * PUT /api/production/:id/status
 * 更新工单状态: planned → in_progress → completed, or → cancelled
 */
router.put('/:id/status', requirePermission('production', 'edit'), (req, res) => {
    const db = getDB();
    const { status } = req.body;
    const order = db.prepare('SELECT * FROM production_orders WHERE id = ?').get(req.params.id);
    if (!order) throw new NotFoundError('生产工单');

    // 状态机校验
    const validTransitions = {
        'planned': ['in_progress', 'cancelled'],
        'in_progress': ['completed', 'cancelled'],
        'completed': [],
        'cancelled': []
    };

    if (!validTransitions[order.status]?.includes(status)) {
        throw new ValidationError(`无法从"${order.status}"变更为"${status}"`);
    }

    const statusLabels = { planned: '计划中', in_progress: '生产中', completed: '已完成', cancelled: '已取消' };

    const doStatusChange = db.transaction(() => {
        // 开始生产：扣减物料库存
        if (status === 'in_progress') {
            const materials = db.prepare(`
                SELECT sm.material_id, m.name, m.unit,
                       sm.quantity_per_unit * ? as total_needed,
                       COALESCE((SELECT SUM(i.quantity) FROM inventory i WHERE i.material_id = sm.material_id AND i.warehouse_id = ?), 0) as available
                FROM sop_materials sm
                JOIN materials m ON sm.material_id = m.id
                WHERE sm.sop_id = ?
            `).all(order.planned_quantity, order.warehouse_id, order.sop_id);

            // 检查库存
            const insufficient = materials.filter(m => m.available < m.total_needed);
            if (insufficient.length > 0) {
                const msg = insufficient.map(m => `${m.name}: 库存 ${m.available} ${m.unit}，需要 ${m.total_needed} ${m.unit}`).join('\n');
                throw new ValidationError('物料不足，无法开始生产:\n' + msg);
            }

            // 扣减库存（已预先检查，跳过服务层重复检查）
            materials.forEach(m => {
                deductStock(db, {
                    materialId: m.material_id, warehouseId: order.warehouse_id,
                    quantity: m.total_needed, referenceNo: order.order_no,
                    notes: `生产领料: ${order.order_no}`,
                    source: 'production_start', userId: req.session.user.id, skipCheck: true
                });
            });

            db.prepare("UPDATE production_orders SET status = 'in_progress', started_at = datetime('now','localtime') WHERE id = ?").run(order.id);
        }
        // 完成生产：产出物料入库
        else if (status === 'completed') {
            const completedQty = order.completed_quantity || order.planned_quantity;

            if (order.output_material_id) {
                addStock(db, {
                    materialId: order.output_material_id, warehouseId: order.warehouse_id,
                    quantity: completedQty, referenceNo: order.order_no,
                    notes: `生产入库: ${order.order_no}`,
                    source: 'production_complete', userId: req.session.user.id
                });
            }

            db.prepare("UPDATE production_orders SET status = 'completed', completed_quantity = ?, completed_at = datetime('now','localtime') WHERE id = ?")
                .run(completedQty, order.id);
        }
        // 取消：退回已领物料
        else if (status === 'cancelled') {
            if (order.status === 'in_progress') {
                const materials = db.prepare(`
                    SELECT sm.material_id, m.name, sm.quantity_per_unit * ? as total_needed
                    FROM sop_materials sm
                    JOIN materials m ON sm.material_id = m.id
                    WHERE sm.sop_id = ?
                `).all(order.planned_quantity, order.sop_id);

                materials.forEach(m => {
                    addStock(db, {
                        materialId: m.material_id, warehouseId: order.warehouse_id,
                        quantity: m.total_needed, referenceNo: order.order_no,
                        notes: `生产取消退料: ${order.order_no}`,
                        source: 'production_cancel', userId: req.session.user.id
                    });
                });
            }

            db.prepare("UPDATE production_orders SET status = 'cancelled' WHERE id = ?").run(order.id);
        }
    });

    doStatusChange();

    logOperation({
        userId: req.session.user.id, action: 'update', resource: 'production',
        resourceId: order.id,
        detail: `工单 ${order.order_no} 状态: ${statusLabels[order.status]} → ${statusLabels[status]}`,
        ip: req.ip
    });

    res.json({ success: true });
});

/**
 * PUT /api/production/:id/progress
 * 更新已完成数量
 */
router.put('/:id/progress', requirePermission('production', 'edit'), (req, res) => {
    const db = getDB();
    const { completedQuantity } = req.body;
    const order = db.prepare('SELECT * FROM production_orders WHERE id = ?').get(req.params.id);
    if (!order) throw new NotFoundError('生产工单');
    if (order.status !== 'in_progress') throw new ValidationError('只有生产中的工单可以更新进度');
    if (completedQuantity < 0 || completedQuantity > order.planned_quantity) throw new ValidationError('完成数量无效');

    db.prepare('UPDATE production_orders SET completed_quantity = ? WHERE id = ?').run(completedQuantity, order.id);

    res.json({ success: true });
});

module.exports = router;
