/**
 * 物料管理路由
 * GET    /api/materials          - 物料列表（支持拼音搜索、分页、筛选）
 * POST   /api/materials          - 创建物料
 * GET    /api/materials/:id      - 物料详情
 * PUT    /api/materials/:id      - 修改物料
 * DELETE /api/materials/:id      - 删除（软删除）物料
 * GET    /api/materials/export/csv - 导出物料CSV
 * POST   /api/materials/batch-import - 批量导入（预留）
 */

const express = require('express');
const { getDB } = require('../db/database');
const { requireAuth } = require('../middleware/auth');
const { requirePermission } = require('../middleware/permission');
const { ValidationError, NotFoundError, ConflictError } = require('../utils/errors');
const { generatePinyinFields, buildSearchCondition } = require('../utils/pinyin');
const { logOperation } = require('../utils/logger');

const router = express.Router();

// 所有物料接口需要登录
router.use(requireAuth);

/**
 * 自动生成物料编码 MAT-YYYYMMDD-NNN
 */
function generateMaterialCode(db) {
    const today = new Date();
    const dateStr = today.getFullYear().toString() +
        String(today.getMonth() + 1).padStart(2, '0') +
        String(today.getDate()).padStart(2, '0');
    const prefix = `MAT-${dateStr}-`;

    const last = db.prepare(
        "SELECT code FROM materials WHERE code LIKE ? ORDER BY code DESC LIMIT 1"
    ).get(`${prefix}%`);

    let seq = 1;
    if (last) {
        const lastSeq = parseInt(last.code.split('-').pop(), 10);
        if (!isNaN(lastSeq)) seq = lastSeq + 1;
    }
    return `${prefix}${String(seq).padStart(3, '0')}`;
}

/**
 * GET /api/materials
 * 物料列表 - 支持搜索、分页、分类筛选
 *
 * Query params:
 *   q          - 搜索关键词（支持中文、全拼、简拼、编码）
 *   category   - 分类ID筛选
 *   active     - 1=仅启用 0=仅禁用（默认1）
 *   page       - 页码（默认1）
 *   limit      - 每页条数（默认20，最大100）
 *   sort       - 排序字段（默认 updated_at）
 *   order      - asc/desc（默认 desc）
 */
router.get('/', requirePermission('materials', 'view'), (req, res) => {
    const db = getDB();
    const {
        q = '',
        category = '',
        active = '1',
        page = '1',
        limit = '20',
        sort = 'updated_at',
        order = 'desc'
    } = req.query;

    // 分页参数
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
    const offset = (pageNum - 1) * pageSize;

    // 排序验证
    const allowedSorts = ['id', 'code', 'name', 'category_id', 'cost_price', 'sale_price', 'created_at', 'updated_at'];
    const sortField = allowedSorts.includes(sort) ? sort : 'updated_at';
    const sortOrder = order.toLowerCase() === 'asc' ? 'ASC' : 'DESC';

    // 构建查询条件
    const conditions = [];
    const params = [];

    // 搜索条件（拼音 + 名称 + 编码，加 m. 前缀避免 JOIN 歧义）
    if (q.trim()) {
        const search = buildSearchCondition(q, {
            nameField: 'm.name',
            pinyinField: 'm.name_pinyin',
            abbrField: 'm.name_pinyin_abbr',
            codeField: 'm.code'
        });
        conditions.push(search.where);
        params.push(...search.params);
    }

    // 分类筛选
    if (category) {
        conditions.push('m.category_id = ?');
        params.push(parseInt(category, 10));
    }

    // 启用/禁用筛选
    if (active !== '') {
        conditions.push('m.is_active = ?');
        params.push(parseInt(active, 10));
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    // 查询总数
    const countRow = db.prepare(
        `SELECT COUNT(*) as total FROM materials m LEFT JOIN categories c ON m.category_id = c.id ${whereClause}`
    ).get(...params);

    // 查询数据（带分类名称）
    const materials = db.prepare(`
        SELECT m.*, c.name as category_name
        FROM materials m
        LEFT JOIN categories c ON m.category_id = c.id
        ${whereClause}
        ORDER BY m.${sortField} ${sortOrder}
        LIMIT ? OFFSET ?
    `).all(...params, pageSize, offset);

    // 查询每个物料的库存总量
    const materialIds = materials.map(m => m.id);
    let inventoryMap = {};
    if (materialIds.length > 0) {
        const placeholders = materialIds.map(() => '?').join(',');
        const inventoryRows = db.prepare(`
            SELECT material_id, SUM(quantity) as total_quantity
            FROM inventory
            WHERE material_id IN (${placeholders})
            GROUP BY material_id
        `).all(...materialIds);
        inventoryRows.forEach(row => {
            inventoryMap[row.material_id] = row.total_quantity;
        });
    }

    // 附加库存信息和低库存标记
    const enrichedMaterials = materials.map(m => ({
        ...m,
        total_stock: inventoryMap[m.id] || 0,
        is_low_stock: (inventoryMap[m.id] || 0) <= m.min_stock
    }));

    res.json({
        success: true,
        data: {
            materials: enrichedMaterials,
            pagination: {
                page: pageNum,
                limit: pageSize,
                total: countRow.total,
                totalPages: Math.ceil(countRow.total / pageSize)
            }
        }
    });
});

/**
 * GET /api/materials/:id
 * 物料详情（含各仓库库存明细）
 */
router.get('/:id', requirePermission('materials', 'view'), (req, res) => {
    const db = getDB();
    const material = db.prepare(`
        SELECT m.*, c.name as category_name
        FROM materials m
        LEFT JOIN categories c ON m.category_id = c.id
        WHERE m.id = ?
    `).get(req.params.id);

    if (!material) throw new NotFoundError('物料');

    // 各仓库库存
    const inventory = db.prepare(`
        SELECT i.*, w.name as warehouse_name
        FROM inventory i
        JOIN warehouses w ON i.warehouse_id = w.id
        WHERE i.material_id = ?
        ORDER BY w.name
    `).all(req.params.id);

    // 最近出入库记录
    const recentMovements = db.prepare(`
        SELECT sm.*, w.name as warehouse_name, u.display_name as operator_name
        FROM stock_movements sm
        JOIN warehouses w ON sm.warehouse_id = w.id
        LEFT JOIN users u ON sm.created_by = u.id
        WHERE sm.material_id = ?
        ORDER BY sm.created_at DESC
        LIMIT 20
    `).all(req.params.id);

    res.json({
        success: true,
        data: {
            material,
            inventory,
            recentMovements
        }
    });
});

/**
 * POST /api/materials
 * 创建物料
 */
router.post('/', requirePermission('materials', 'add'), (req, res) => {
    const {
        name, categoryId, unit, spec, brand, description,
        minStock, maxStock, costPrice, salePrice,
        imageUrl, barcode, weight, dimensions,
        supplier, supplierContact, notes, code
    } = req.body;

    // 验证
    if (!name || !name.trim()) throw new ValidationError('请输入物料名称', 'name');
    if (!unit || !unit.trim()) throw new ValidationError('请输入单位', 'unit');

    const db = getDB();

    // 生成拼音索引
    const { fullPinyin, abbr } = generatePinyinFields(name.trim());

    const doCreate = db.transaction(() => {
        // 生成编码（用户也可自定义）——放在事务内防止并发重复
        const materialCode = code?.trim() || generateMaterialCode(db);

        // 检查编码唯一性
        const existing = db.prepare('SELECT id FROM materials WHERE code = ?').get(materialCode);
        if (existing) throw new ConflictError(`物料编码 ${materialCode} 已存在`);

        const result = db.prepare(`
            INSERT INTO materials (
                code, name, name_pinyin, name_pinyin_abbr,
                category_id, unit, spec, brand, description,
                min_stock, max_stock, cost_price, sale_price,
                image_url, barcode, weight, dimensions,
                supplier, supplier_contact, notes, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            materialCode, name.trim(), fullPinyin, abbr,
            categoryId || null, unit.trim(), spec || null, brand || null, description || null,
            minStock || 0, maxStock || null, costPrice || 0, salePrice || 0,
            imageUrl || null, barcode || null, weight || null, dimensions || null,
            supplier || null, supplierContact || null, notes || null, req.session.user.id
        );

        return { id: result.lastInsertRowid, materialCode };
    });

    const { id: newId, materialCode } = doCreate();

    logOperation({
        userId: req.session.user.id,
        action: 'create',
        resource: 'materials',
        resourceId: newId,
        detail: `创建物料: ${name} (${materialCode})`,
        ip: req.ip
    });

    res.status(201).json({
        success: true,
        data: {
            id: newId,
            code: materialCode,
            name: name.trim()
        }
    });
});

/**
 * PUT /api/materials/:id
 * 修改物料
 */
router.put('/:id', requirePermission('materials', 'edit'), (req, res) => {
    const { id } = req.params;
    const {
        name, categoryId, unit, spec, brand, description,
        minStock, maxStock, costPrice, salePrice,
        imageUrl, barcode, weight, dimensions,
        supplier, supplierContact, notes, code
    } = req.body;

    const db = getDB();
    const material = db.prepare('SELECT * FROM materials WHERE id = ?').get(id);
    if (!material) throw new NotFoundError('物料');

    // 如果修改了编码，检查唯一性
    if (code && code.trim() !== material.code) {
        const existing = db.prepare('SELECT id FROM materials WHERE code = ? AND id != ?').get(code.trim(), id);
        if (existing) throw new ConflictError(`物料编码 ${code} 已存在`);
    }

    // 如果修改了名称，重新生成拼音
    const finalName = name?.trim() || material.name;
    let pinyinFields = { fullPinyin: material.name_pinyin, abbr: material.name_pinyin_abbr };
    if (name && name.trim() !== material.name) {
        pinyinFields = generatePinyinFields(finalName);
    }

    db.prepare(`
        UPDATE materials SET
            code = COALESCE(?, code),
            name = ?,
            name_pinyin = ?,
            name_pinyin_abbr = ?,
            category_id = ?,
            unit = COALESCE(?, unit),
            spec = ?,
            brand = ?,
            description = ?,
            min_stock = COALESCE(?, min_stock),
            max_stock = ?,
            cost_price = COALESCE(?, cost_price),
            sale_price = COALESCE(?, sale_price),
            image_url = ?,
            barcode = ?,
            weight = ?,
            dimensions = ?,
            supplier = ?,
            supplier_contact = ?,
            notes = ?,
            updated_at = datetime('now', 'localtime')
        WHERE id = ?
    `).run(
        code?.trim() || null,
        finalName,
        pinyinFields.fullPinyin,
        pinyinFields.abbr,
        categoryId !== undefined ? (categoryId || null) : material.category_id,
        unit?.trim() || null,
        spec !== undefined ? spec : material.spec,
        brand !== undefined ? brand : material.brand,
        description !== undefined ? description : material.description,
        minStock !== undefined ? minStock : null,
        maxStock !== undefined ? maxStock : null,
        costPrice !== undefined ? costPrice : null,
        salePrice !== undefined ? salePrice : null,
        imageUrl !== undefined ? imageUrl : material.image_url,
        barcode !== undefined ? barcode : material.barcode,
        weight !== undefined ? weight : material.weight,
        dimensions !== undefined ? dimensions : material.dimensions,
        supplier !== undefined ? supplier : material.supplier,
        supplierContact !== undefined ? supplierContact : material.supplier_contact,
        notes !== undefined ? notes : material.notes,
        id
    );

    logOperation({
        userId: req.session.user.id,
        action: 'update',
        resource: 'materials',
        resourceId: Number(id),
        detail: `修改物料: ${finalName}`,
        ip: req.ip
    });

    res.json({ success: true, message: '物料已更新' });
});

/**
 * DELETE /api/materials/:id
 * 软删除物料
 */
router.delete('/:id', requirePermission('materials', 'delete'), (req, res) => {
    const { id } = req.params;
    const db = getDB();

    const material = db.prepare('SELECT * FROM materials WHERE id = ?').get(id);
    if (!material) throw new NotFoundError('物料');

    // 检查是否有库存
    const stock = db.prepare(
        'SELECT SUM(quantity) as total FROM inventory WHERE material_id = ?'
    ).get(id);
    if (stock && stock.total > 0) {
        throw new ValidationError(`该物料还有 ${stock.total} ${material.unit} 库存，请先清零后再删除`);
    }

    // 检查是否在活跃BOM中使用
    const bomUsage = db.prepare(`
        SELECT COUNT(*) as cnt FROM bom_items bi
        JOIN boms b ON bi.bom_id = b.id
        WHERE bi.material_id = ? AND b.is_active = 1
    `).get(id);
    if (bomUsage && bomUsage.cnt > 0) {
        throw new ValidationError(`该物料在 ${bomUsage.cnt} 个活跃BOM中使用，无法删除`);
    }

    // 检查是否在SOP中使用
    const sopUsage = db.prepare(`
        SELECT COUNT(*) as cnt FROM sop_materials sm
        JOIN sops s ON sm.sop_id = s.id
        WHERE sm.material_id = ? AND s.is_active = 1
    `).get(id);
    if (sopUsage && sopUsage.cnt > 0) {
        throw new ValidationError(`该物料在 ${sopUsage.cnt} 个活跃SOP中使用，无法删除`);
    }

    db.prepare(
        "UPDATE materials SET is_active = 0, updated_at = datetime('now', 'localtime') WHERE id = ?"
    ).run(id);

    logOperation({
        userId: req.session.user.id,
        action: 'delete',
        resource: 'materials',
        resourceId: Number(id),
        detail: `禁用物料: ${material.name} (${material.code})`,
        ip: req.ip
    });

    res.json({ success: true, message: '物料已删除' });
});

/**
 * GET /api/categories
 * 获取分类列表
 */
router.get('/meta/categories', (req, res) => {
    const db = getDB();
    const categories = db.prepare(`
        SELECT c.*, COUNT(m.id) as material_count
        FROM categories c
        LEFT JOIN materials m ON m.category_id = c.id AND m.is_active = 1
        GROUP BY c.id
        ORDER BY c.sort_order, c.name
    `).all();

    res.json({ success: true, data: { categories } });
});

/**
 * POST /api/materials/meta/categories
 * 创建分类
 */
router.post('/meta/categories', requirePermission('categories', 'add'), (req, res) => {
    const { name, parentId } = req.body;
    if (!name || !name.trim()) throw new ValidationError('请输入分类名称', 'name');

    const db = getDB();
    const { fullPinyin, abbr } = generatePinyinFields(name.trim());

    const result = db.prepare(`
        INSERT INTO categories (name, name_pinyin, name_pinyin_abbr, parent_id)
        VALUES (?, ?, ?, ?)
    `).run(name.trim(), fullPinyin, abbr, parentId || null);

    res.status(201).json({
        success: true,
        data: { id: result.lastInsertRowid, name: name.trim() }
    });
});

/**
 * PUT /api/materials/meta/categories/:id
 */
router.put('/meta/categories/:id', requirePermission('categories', 'edit'), (req, res) => {
    const { name, parentId, sortOrder } = req.body;
    const db = getDB();

    const cat = db.prepare('SELECT * FROM categories WHERE id = ?').get(req.params.id);
    if (!cat) throw new NotFoundError('分类');

    const finalName = name?.trim() || cat.name;
    let py = { fullPinyin: cat.name_pinyin, abbr: cat.name_pinyin_abbr };
    if (name && name.trim() !== cat.name) {
        py = generatePinyinFields(finalName);
    }

    db.prepare(`
        UPDATE categories SET name = ?, name_pinyin = ?, name_pinyin_abbr = ?,
        parent_id = ?, sort_order = COALESCE(?, sort_order)
        WHERE id = ?
    `).run(finalName, py.fullPinyin, py.abbr, parentId !== undefined ? parentId : cat.parent_id, sortOrder, req.params.id);

    res.json({ success: true, message: '分类已更新' });
});

/**
 * DELETE /api/materials/meta/categories/:id
 */
router.delete('/meta/categories/:id', requirePermission('categories', 'delete'), (req, res) => {
    const db = getDB();
    const cat = db.prepare('SELECT * FROM categories WHERE id = ?').get(req.params.id);
    if (!cat) throw new NotFoundError('分类');

    // 检查是否有物料使用此分类
    const count = db.prepare('SELECT COUNT(*) as cnt FROM materials WHERE category_id = ? AND is_active = 1').get(req.params.id);
    if (count.cnt > 0) {
        throw new ValidationError(`该分类下还有 ${count.cnt} 个物料，请先转移后再删除`);
    }

    // 将子分类的 parent_id 置空
    db.prepare('UPDATE categories SET parent_id = NULL WHERE parent_id = ?').run(req.params.id);
    db.prepare('DELETE FROM categories WHERE id = ?').run(req.params.id);

    res.json({ success: true, message: '分类已删除' });
});

module.exports = router;
