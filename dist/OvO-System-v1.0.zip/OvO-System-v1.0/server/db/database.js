/**
 * 数据库连接管理
 * 单例模式，整个应用共享一个数据库连接
 */

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, '../../data/inventory.db');

let db = null;

/**
 * 获取数据库连接（单例）
 */
function getDB() {
    if (!db) {
        db = new Database(DB_PATH);
        db.pragma('journal_mode = WAL');
        db.pragma('foreign_keys = ON');
        // 提升并发性能
        db.pragma('busy_timeout = 5000');
        // 在线迁移：stock_movements 增加 source 字段
        runMigrations(db);
    }
    return db;
}

/**
 * 自动迁移：检查并添加缺失的列
 */
function runMigrations(database) {
    try {
        // 迁移1: stock_movements 增加 source 字段
        const columns = database.prepare("PRAGMA table_info(stock_movements)").all();
        const hasSource = columns.some(c => c.name === 'source');
        if (!hasSource) {
            database.exec("ALTER TABLE stock_movements ADD COLUMN source TEXT");
            database.exec("CREATE INDEX IF NOT EXISTS idx_movements_source ON stock_movements(source)");
            console.log('📦 迁移完成: stock_movements 增加 source 字段');
        }

        // 迁移2: 移除旧的非负库存触发器（业务允许负库存 = 欠料）
        const triggers = database.prepare(
            "SELECT name FROM sqlite_master WHERE type='trigger' AND name='prevent_negative_inventory'"
        ).get();
        if (triggers) {
            database.exec("DROP TRIGGER prevent_negative_inventory");
            console.log('📦 迁移完成: 移除非负库存触发器（允许负库存）');
        }
    } catch (e) {
        // 表可能不存在（首次初始化前），忽略
    }
}

/**
 * 关闭数据库连接
 */
function closeDB() {
    if (db) {
        db.close();
        db = null;
    }
}

module.exports = { getDB, closeDB };
