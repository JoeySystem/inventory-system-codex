/**
 * 仓库管理路由
 * GET    /api/warehouses          - 仓库列表
 * POST   /api/warehouses          - 创建仓库
 * GET    /api/warehouses/:id      - 仓库详情（含库存）
 * PUT    /api/warehouses/:id      - 修改仓库
 * DELETE /api/warehouses/:id      - 删除仓库
 * GET    /api/warehouses/:id/inventory - 仓库库存明细
 * POST   /api/warehouses/:id/stock-in  - 入库操作
 * POST   /api/warehouses/:id/stock-out - 出库操作
 * POST   /api/warehouses/transfer      - 仓库间调拨
 */

const express = require('express');
const { getDB } = require('../db/database');
const { requireAuth } = require('../middleware/auth');
const { requirePermission } = require('../middleware/permission');
const { ValidationError, NotFoundError, ConflictError } = require('../utils/errors');
const { generatePinyinFields, buildSearchCondition } = require('../utils/pinyin');
const { logOperation } = require('../utils/logger');

const router = express.Router();

router.use(requireAuth);

/**
 * GET /api/warehouses
 * 仓库列表
 */
router.get('/', requirePermission('warehouses', 'view'), (req, res) => {
    const db = getDB();
    const { q = '', active = '1' } = req.query;

    const conditions = [];
    const params = [];

    if (q.trim()) {
        const search = buildSearchCondition(q);
        conditions.push(search.where);
        params.push(...search.params);
    }

    if (active !== '') {
        conditions.push('w.is_active = ?');
        params.push(parseInt(active, 10));
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const warehouses = db.prepare(`
        SELECT w.*,
            COUNT(DISTINCT i.material_id) as material_types,
            COALESCE(SUM(i.quantity), 0) as total_quantity
        FROM warehouses w
        LEFT JOIN inventory i ON w.id = i.warehouse_id AND i.quantity > 0
        ${whereClause}
        GROUP BY w.id
        ORDER BY w.created_at ASC
    `).all(...params);

    res.json({ success: true, data: { warehouses } });
});

/**
 * GET /api/warehouses/:id
 * 仓库详情
 */
router.get('/:id', requirePermission('warehouses', 'view'), (req, res) => {
    const db = getDB();
    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ?').get(req.params.id);
    if (!warehouse) throw new NotFoundError('仓库');

    // 该仓库的库存概况
    const stats = db.prepare(`
        SELECT
            COUNT(DISTINCT material_id) as material_types,
            COALESCE(SUM(quantity), 0) as total_quantity
        FROM inventory
        WHERE warehouse_id = ? AND quantity > 0
    `).get(req.params.id);

    res.json({
        success: true,
        data: { warehouse, stats }
    });
});

/**
 * GET /api/warehouses/:id/inventory
 * 仓库库存明细
 */
router.get('/:id/inventory', requirePermission('warehouses', 'view'), (req, res) => {
    const db = getDB();
    const { q = '', page = '1', limit = '20' } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
    const offset = (pageNum - 1) * pageSize;

    let searchWhere = '';
    const params = [req.params.id];

    if (q.trim()) {
        const search = buildSearchCondition(q, { codeField: 'm.code' });
        // 需要给字段加表前缀
        const prefixedWhere = search.where
            .replace(/\bname\b/g, 'm.name')
            .replace(/\bname_pinyin\b/g, 'm.name_pinyin')
            .replace(/\bname_pinyin_abbr\b/g, 'm.name_pinyin_abbr');
        searchWhere = `AND ${prefixedWhere}`;
        params.push(...search.params);
    }

    const countRow = db.prepare(`
        SELECT COUNT(*) as total
        FROM inventory i
        JOIN materials m ON i.material_id = m.id
        WHERE i.warehouse_id = ? AND i.quantity > 0 ${searchWhere}
    `).get(...params);

    const items = db.prepare(`
        SELECT i.*, m.code, m.name, m.unit, m.spec, m.brand, m.min_stock,
               m.cost_price, m.sale_price, c.name as category_name
        FROM inventory i
        JOIN materials m ON i.material_id = m.id
        LEFT JOIN categories c ON m.category_id = c.id
        WHERE i.warehouse_id = ? AND i.quantity > 0 ${searchWhere}
        ORDER BY m.name
        LIMIT ? OFFSET ?
    `).all(...params, pageSize, offset);

    res.json({
        success: true,
        data: {
            items,
            pagination: {
                page: pageNum,
                limit: pageSize,
                total: countRow.total,
                totalPages: Math.ceil(countRow.total / pageSize)
            }
        }
    });
});

/**
 * POST /api/warehouses
 * 创建仓库
 */
router.post('/', requirePermission('warehouses', 'add'), (req, res) => {
    const { name, address, contactPerson, contactPhone, notes } = req.body;

    if (!name || !name.trim()) throw new ValidationError('请输入仓库名称', 'name');

    const db = getDB();
    const { fullPinyin, abbr } = generatePinyinFields(name.trim());

    const result = db.prepare(`
        INSERT INTO warehouses (name, name_pinyin, name_pinyin_abbr, address, contact_person, contact_phone, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(name.trim(), fullPinyin, abbr, address || null, contactPerson || null, contactPhone || null, notes || null);

    logOperation({
        userId: req.session.user.id,
        action: 'create',
        resource: 'warehouses',
        resourceId: result.lastInsertRowid,
        detail: `创建仓库: ${name}`,
        ip: req.ip
    });

    res.status(201).json({
        success: true,
        data: { id: result.lastInsertRowid, name: name.trim() }
    });
});

/**
 * PUT /api/warehouses/:id
 * 修改仓库
 */
router.put('/:id', requirePermission('warehouses', 'edit'), (req, res) => {
    const { name, address, contactPerson, contactPhone, notes } = req.body;
    const db = getDB();

    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ?').get(req.params.id);
    if (!warehouse) throw new NotFoundError('仓库');

    const finalName = name?.trim() || warehouse.name;
    let py = { fullPinyin: warehouse.name_pinyin, abbr: warehouse.name_pinyin_abbr };
    if (name && name.trim() !== warehouse.name) {
        py = generatePinyinFields(finalName);
    }

    db.prepare(`
        UPDATE warehouses SET
            name = ?, name_pinyin = ?, name_pinyin_abbr = ?,
            address = ?, contact_person = ?, contact_phone = ?, notes = ?,
            updated_at = datetime('now', 'localtime')
        WHERE id = ?
    `).run(
        finalName, py.fullPinyin, py.abbr,
        address !== undefined ? address : warehouse.address,
        contactPerson !== undefined ? contactPerson : warehouse.contact_person,
        contactPhone !== undefined ? contactPhone : warehouse.contact_phone,
        notes !== undefined ? notes : warehouse.notes,
        req.params.id
    );

    logOperation({
        userId: req.session.user.id,
        action: 'update',
        resource: 'warehouses',
        resourceId: Number(req.params.id),
        detail: `修改仓库: ${finalName}`,
        ip: req.ip
    });

    res.json({ success: true, message: '仓库信息已更新' });
});

/**
 * DELETE /api/warehouses/:id
 * 删除仓库（软删除）
 */
router.delete('/:id', requirePermission('warehouses', 'delete'), (req, res) => {
    const db = getDB();
    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ?').get(req.params.id);
    if (!warehouse) throw new NotFoundError('仓库');

    // 检查是否有库存
    const stock = db.prepare(
        'SELECT SUM(quantity) as total FROM inventory WHERE warehouse_id = ?'
    ).get(req.params.id);
    if (stock && stock.total > 0) {
        throw new ValidationError('该仓库还有库存，请先清空后再删除');
    }

    db.prepare(
        "UPDATE warehouses SET is_active = 0, updated_at = datetime('now', 'localtime') WHERE id = ?"
    ).run(req.params.id);

    logOperation({
        userId: req.session.user.id,
        action: 'delete',
        resource: 'warehouses',
        resourceId: Number(req.params.id),
        detail: `删除仓库: ${warehouse.name}`,
        ip: req.ip
    });

    res.json({ success: true, message: '仓库已删除' });
});

/**
 * POST /api/warehouses/:id/stock-in
 * 入库操作
 */
router.post('/:id/stock-in', requirePermission('materials', 'edit'), (req, res) => {
    const { materialId, quantity, unitPrice, counterparty, referenceNo, notes } = req.body;
    const warehouseId = req.params.id;

    if (!materialId) throw new ValidationError('请选择物料', 'materialId');
    if (!quantity || quantity <= 0) throw new ValidationError('数量必须大于0', 'quantity');

    const db = getDB();

    // 验证仓库和物料存在
    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ? AND is_active = 1').get(warehouseId);
    if (!warehouse) throw new NotFoundError('仓库');
    const material = db.prepare('SELECT * FROM materials WHERE id = ? AND is_active = 1').get(materialId);
    if (!material) throw new NotFoundError('物料');

    const totalPrice = unitPrice ? unitPrice * quantity : null;

    // 事务：更新库存 + 记录流水
    const doStockIn = db.transaction(() => {
        // 更新或插入库存
        const existing = db.prepare(
            'SELECT * FROM inventory WHERE material_id = ? AND warehouse_id = ?'
        ).get(materialId, warehouseId);

        if (existing) {
            db.prepare(`
                UPDATE inventory SET quantity = quantity + ?, updated_at = datetime('now', 'localtime')
                WHERE material_id = ? AND warehouse_id = ?
            `).run(quantity, materialId, warehouseId);
        } else {
            db.prepare(`
                INSERT INTO inventory (material_id, warehouse_id, quantity)
                VALUES (?, ?, ?)
            `).run(materialId, warehouseId, quantity);
        }

        // 记录流水
        db.prepare(`
            INSERT INTO stock_movements (type, material_id, warehouse_id, quantity, unit_price, total_price, counterparty, reference_no, notes, created_by)
            VALUES ('in', ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(materialId, warehouseId, quantity, unitPrice || null, totalPrice, counterparty || null, referenceNo || null, notes || null, req.session.user.id);
    });

    doStockIn();

    logOperation({
        userId: req.session.user.id,
        action: 'create',
        resource: 'materials',
        resourceId: materialId,
        detail: `入库: ${material.name} × ${quantity} → ${warehouse.name}`,
        ip: req.ip
    });

    res.json({ success: true, message: `${material.name} × ${quantity} 入库成功` });
});

/**
 * POST /api/warehouses/:id/stock-out
 * 出库操作
 */
router.post('/:id/stock-out', requirePermission('materials', 'edit'), (req, res) => {
    const { materialId, quantity, unitPrice, counterparty, referenceNo, notes } = req.body;
    const warehouseId = req.params.id;

    if (!materialId) throw new ValidationError('请选择物料', 'materialId');
    if (!quantity || quantity <= 0) throw new ValidationError('数量必须大于0', 'quantity');

    const db = getDB();

    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ? AND is_active = 1').get(warehouseId);
    if (!warehouse) throw new NotFoundError('仓库');
    const material = db.prepare('SELECT * FROM materials WHERE id = ? AND is_active = 1').get(materialId);
    if (!material) throw new NotFoundError('物料');

    // 检查库存是否充足
    const inv = db.prepare(
        'SELECT quantity FROM inventory WHERE material_id = ? AND warehouse_id = ?'
    ).get(materialId, warehouseId);
    const currentQty = inv ? inv.quantity : 0;
    if (currentQty < quantity) {
        throw new ValidationError(`库存不足，当前库存: ${currentQty} ${material.unit}，需要: ${quantity} ${material.unit}`);
    }

    const totalPrice = unitPrice ? unitPrice * quantity : null;

    const doStockOut = db.transaction(() => {
        db.prepare(`
            UPDATE inventory SET quantity = quantity - ?, updated_at = datetime('now', 'localtime')
            WHERE material_id = ? AND warehouse_id = ?
        `).run(quantity, materialId, warehouseId);

        db.prepare(`
            INSERT INTO stock_movements (type, material_id, warehouse_id, quantity, unit_price, total_price, counterparty, reference_no, notes, created_by)
            VALUES ('out', ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(materialId, warehouseId, quantity, unitPrice || null, totalPrice, counterparty || null, referenceNo || null, notes || null, req.session.user.id);
    });

    doStockOut();

    logOperation({
        userId: req.session.user.id,
        action: 'create',
        resource: 'materials',
        resourceId: materialId,
        detail: `出库: ${material.name} × ${quantity} ← ${warehouse.name}`,
        ip: req.ip
    });

    res.json({ success: true, message: `${material.name} × ${quantity} 出库成功` });
});

/**
 * POST /api/warehouses/transfer
 * 仓库间调拨
 */
router.post('/transfer', requirePermission('warehouses', 'edit'), (req, res) => {
    const { materialId, fromWarehouseId, toWarehouseId, quantity, notes } = req.body;

    if (!materialId) throw new ValidationError('请选择物料');
    if (!fromWarehouseId) throw new ValidationError('请选择源仓库');
    if (!toWarehouseId) throw new ValidationError('请选择目标仓库');
    if (fromWarehouseId === toWarehouseId) throw new ValidationError('源仓库和目标仓库不能相同');
    if (!quantity || quantity <= 0) throw new ValidationError('数量必须大于0');

    const db = getDB();

    const material = db.prepare('SELECT * FROM materials WHERE id = ?').get(materialId);
    if (!material) throw new NotFoundError('物料');
    const fromWh = db.prepare('SELECT * FROM warehouses WHERE id = ? AND is_active = 1').get(fromWarehouseId);
    if (!fromWh) throw new NotFoundError('源仓库');
    const toWh = db.prepare('SELECT * FROM warehouses WHERE id = ? AND is_active = 1').get(toWarehouseId);
    if (!toWh) throw new NotFoundError('目标仓库');

    // 检查源仓库库存
    const inv = db.prepare(
        'SELECT quantity FROM inventory WHERE material_id = ? AND warehouse_id = ?'
    ).get(materialId, fromWarehouseId);
    const currentQty = inv ? inv.quantity : 0;
    if (currentQty < quantity) {
        throw new ValidationError(`${fromWh.name} 库存不足，当前: ${currentQty}，需要: ${quantity}`);
    }

    const doTransfer = db.transaction(() => {
        // 源仓库减
        db.prepare(`
            UPDATE inventory SET quantity = quantity - ?, updated_at = datetime('now', 'localtime')
            WHERE material_id = ? AND warehouse_id = ?
        `).run(quantity, materialId, fromWarehouseId);

        // 目标仓库加
        const existing = db.prepare(
            'SELECT * FROM inventory WHERE material_id = ? AND warehouse_id = ?'
        ).get(materialId, toWarehouseId);
        if (existing) {
            db.prepare(`
                UPDATE inventory SET quantity = quantity + ?, updated_at = datetime('now', 'localtime')
                WHERE material_id = ? AND warehouse_id = ?
            `).run(quantity, materialId, toWarehouseId);
        } else {
            db.prepare(`
                INSERT INTO inventory (material_id, warehouse_id, quantity) VALUES (?, ?, ?)
            `).run(materialId, toWarehouseId, quantity);
        }

        // 记录调拨流水
        db.prepare(`
            INSERT INTO stock_movements (type, material_id, warehouse_id, to_warehouse_id, quantity, notes, created_by)
            VALUES ('transfer', ?, ?, ?, ?, ?, ?)
        `).run(materialId, fromWarehouseId, toWarehouseId, quantity, notes || null, req.session.user.id);
    });

    doTransfer();

    logOperation({
        userId: req.session.user.id,
        action: 'create',
        resource: 'warehouses',
        detail: `调拨: ${material.name} × ${quantity} ${fromWh.name} → ${toWh.name}`,
        ip: req.ip
    });

    res.json({ success: true, message: `调拨成功: ${material.name} × ${quantity}` });
});

module.exports = router;
