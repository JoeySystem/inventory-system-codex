/**
 * 发货管理路由
 * GET    /api/shipments              - 发货单列表
 * POST   /api/shipments              - 创建发货单（含库存校验）
 * GET    /api/shipments/:id          - 发货单详情
 * PUT    /api/shipments/:id/status   - 更新发货单状态
 * DELETE /api/shipments/:id          - 取消发货单
 */

const express = require('express');
const { getDB } = require('../db/database');
const { requireAuth } = require('../middleware/auth');
const { requirePermission } = require('../middleware/permission');
const { ValidationError, NotFoundError } = require('../utils/errors');
const { logOperation } = require('../utils/logger');

const router = express.Router();
router.use(requireAuth);

/**
 * 生成发货单号 SH-YYYYMMDD-NNN
 */
function generateShipmentNo(db) {
    const today = new Date();
    const dateStr = today.getFullYear().toString() +
        String(today.getMonth() + 1).padStart(2, '0') +
        String(today.getDate()).padStart(2, '0');
    const prefix = `SH-${dateStr}-`;
    const last = db.prepare(
        "SELECT shipment_no FROM shipments WHERE shipment_no LIKE ? ORDER BY shipment_no DESC LIMIT 1"
    ).get(`${prefix}%`);
    let seq = 1;
    if (last) {
        const lastSeq = parseInt(last.shipment_no.split('-').pop(), 10);
        if (!isNaN(lastSeq)) seq = lastSeq + 1;
    }
    return `${prefix}${String(seq).padStart(3, '0')}`;
}

/**
 * GET /api/shipments
 */
router.get('/', requirePermission('shipments', 'view'), (req, res) => {
    const db = getDB();
    const { status = '', page = '1', limit = '20' } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
    const offset = (pageNum - 1) * pageSize;

    const conditions = [];
    const params = [];
    if (status) {
        conditions.push('s.status = ?');
        params.push(status);
    }
    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const countRow = db.prepare(
        `SELECT COUNT(*) as total FROM shipments s ${whereClause}`
    ).get(...params);

    const shipments = db.prepare(`
        SELECT s.*, w.name as warehouse_name, u.display_name as creator_name,
               (SELECT COUNT(*) FROM shipment_items si WHERE si.shipment_id = s.id) as item_count
        FROM shipments s
        JOIN warehouses w ON s.warehouse_id = w.id
        LEFT JOIN users u ON s.created_by = u.id
        ${whereClause}
        ORDER BY s.created_at DESC
        LIMIT ? OFFSET ?
    `).all(...params, pageSize, offset);

    res.json({
        success: true,
        data: {
            shipments,
            pagination: { page: pageNum, limit: pageSize, total: countRow.total, totalPages: Math.ceil(countRow.total / pageSize) }
        }
    });
});

/**
 * GET /api/shipments/:id
 */
router.get('/:id', requirePermission('shipments', 'view'), (req, res) => {
    const db = getDB();
    const shipment = db.prepare(`
        SELECT s.*, w.name as warehouse_name, u.display_name as creator_name
        FROM shipments s
        JOIN warehouses w ON s.warehouse_id = w.id
        LEFT JOIN users u ON s.created_by = u.id
        WHERE s.id = ?
    `).get(req.params.id);
    if (!shipment) throw new NotFoundError('发货单');

    const items = db.prepare(`
        SELECT si.*, m.code as material_code, m.name as material_name, m.unit, m.spec
        FROM shipment_items si
        JOIN materials m ON si.material_id = m.id
        WHERE si.shipment_id = ?
    `).all(req.params.id);

    res.json({ success: true, data: { shipment, items } });
});

/**
 * POST /api/shipments/check-stock
 * 预检查库存是否充足（创建发货单前调用）
 */
router.post('/check-stock', requirePermission('shipments', 'add'), (req, res) => {
    const { warehouseId, items } = req.body;
    if (!warehouseId) throw new ValidationError('请选择仓库');
    if (!items || !items.length) throw new ValidationError('请添加物料');

    const db = getDB();
    const results = [];
    let allSufficient = true;

    for (const item of items) {
        const material = db.prepare('SELECT id, name, unit FROM materials WHERE id = ?').get(item.materialId);
        if (!material) continue;

        const inv = db.prepare(
            'SELECT quantity FROM inventory WHERE material_id = ? AND warehouse_id = ?'
        ).get(item.materialId, warehouseId);
        const available = inv ? inv.quantity : 0;
        const sufficient = available >= item.quantity;
        if (!sufficient) allSufficient = false;

        results.push({
            materialId: item.materialId,
            materialName: material.name,
            unit: material.unit,
            requested: item.quantity,
            available,
            sufficient,
            shortage: sufficient ? 0 : item.quantity - available
        });
    }

    res.json({ success: true, data: { allSufficient, items: results } });
});

/**
 * POST /api/shipments
 * 创建发货单（事务：创建单据 + 扣减库存）
 */
router.post('/', requirePermission('shipments', 'add'), (req, res) => {
    const { warehouseId, customerName, customerContact, shippingAddress, items, notes } = req.body;

    if (!warehouseId) throw new ValidationError('请选择仓库', 'warehouseId');
    if (!items || !items.length) throw new ValidationError('请至少添加一个物料');

    // 验证每个物料
    for (const item of items) {
        if (!item.materialId) throw new ValidationError('物料不能为空');
        if (!item.quantity || item.quantity <= 0) throw new ValidationError('数量必须大于0');
    }

    const db = getDB();

    // 验证仓库
    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ? AND is_active = 1').get(warehouseId);
    if (!warehouse) throw new NotFoundError('仓库');

    // 检查所有物料库存
    const stockErrors = [];
    for (const item of items) {
        const material = db.prepare('SELECT * FROM materials WHERE id = ? AND is_active = 1').get(item.materialId);
        if (!material) throw new NotFoundError(`物料 ID ${item.materialId}`);

        const inv = db.prepare(
            'SELECT quantity FROM inventory WHERE material_id = ? AND warehouse_id = ?'
        ).get(item.materialId, warehouseId);
        const available = inv ? inv.quantity : 0;

        if (available < item.quantity) {
            stockErrors.push(`${material.name}: 库存 ${available} ${material.unit}，需要 ${item.quantity} ${material.unit}，缺口 ${item.quantity - available}`);
        }
    }
    if (stockErrors.length > 0) {
        throw new ValidationError('库存不足:\n' + stockErrors.join('\n'));
    }

    // 事务：创建发货单 + 扣减库存
    const shipmentNo = generateShipmentNo(db);
    let totalAmount = 0;

    const doCreate = db.transaction(() => {
        // 创建发货单
        const result = db.prepare(`
            INSERT INTO shipments (shipment_no, customer_name, customer_contact, shipping_address, warehouse_id, status, notes, created_by)
            VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)
        `).run(shipmentNo, customerName || null, customerContact || null, shippingAddress || null, warehouseId, notes || null, req.session.user.id);

        const shipmentId = result.lastInsertRowid;

        // 插入明细 + 扣减库存
        for (const item of items) {
            const material = db.prepare('SELECT * FROM materials WHERE id = ?').get(item.materialId);
            const unitPrice = item.unitPrice || material.sale_price || 0;
            const itemTotal = unitPrice * item.quantity;
            totalAmount += itemTotal;

            // 插入发货明细
            db.prepare(`
                INSERT INTO shipment_items (shipment_id, material_id, quantity, unit_price, total_price)
                VALUES (?, ?, ?, ?, ?)
            `).run(shipmentId, item.materialId, item.quantity, unitPrice, itemTotal);

            // 扣减库存
            db.prepare(`
                UPDATE inventory SET quantity = quantity - ?, updated_at = datetime('now', 'localtime')
                WHERE material_id = ? AND warehouse_id = ?
            `).run(item.quantity, item.materialId, warehouseId);

            // 记录出库流水
            db.prepare(`
                INSERT INTO stock_movements (type, material_id, warehouse_id, quantity, unit_price, total_price, reference_no, counterparty, notes, created_by)
                VALUES ('out', ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).run(item.materialId, warehouseId, item.quantity, unitPrice, itemTotal, shipmentNo, customerName || null, '发货出库', req.session.user.id);
        }

        // 更新总金额
        db.prepare('UPDATE shipments SET total_amount = ? WHERE id = ?').run(totalAmount, shipmentId);

        return shipmentId;
    });

    const shipmentId = doCreate();

    logOperation({
        userId: req.session.user.id,
        action: 'create',
        resource: 'shipments',
        resourceId: shipmentId,
        detail: `创建发货单 ${shipmentNo}，共 ${items.length} 种物料，金额 ¥${totalAmount.toFixed(2)}`,
        ip: req.ip
    });

    res.status(201).json({
        success: true,
        data: { id: shipmentId, shipmentNo, totalAmount }
    });
});

/**
 * PUT /api/shipments/:id/status
 * 更新发货单状态
 */
router.put('/:id/status', requirePermission('shipments', 'edit'), (req, res) => {
    const { status } = req.body;
    const validStatuses = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'];
    if (!validStatuses.includes(status)) throw new ValidationError('无效的状态');

    const db = getDB();
    const shipment = db.prepare('SELECT * FROM shipments WHERE id = ?').get(req.params.id);
    if (!shipment) throw new NotFoundError('发货单');

    // 取消发货单时退回库存
    if (status === 'cancelled' && shipment.status !== 'cancelled') {
        const doCancel = db.transaction(() => {
            const items = db.prepare('SELECT * FROM shipment_items WHERE shipment_id = ?').all(req.params.id);
            for (const item of items) {
                // 退回库存
                const existing = db.prepare(
                    'SELECT * FROM inventory WHERE material_id = ? AND warehouse_id = ?'
                ).get(item.material_id, shipment.warehouse_id);
                if (existing) {
                    db.prepare(`
                        UPDATE inventory SET quantity = quantity + ?, updated_at = datetime('now', 'localtime')
                        WHERE material_id = ? AND warehouse_id = ?
                    `).run(item.quantity, item.material_id, shipment.warehouse_id);
                } else {
                    db.prepare(`
                        INSERT INTO inventory (material_id, warehouse_id, quantity) VALUES (?, ?, ?)
                    `).run(item.material_id, shipment.warehouse_id, item.quantity);
                }

                // 记录入库流水（退货）
                db.prepare(`
                    INSERT INTO stock_movements (type, material_id, warehouse_id, quantity, reference_no, notes, created_by)
                    VALUES ('in', ?, ?, ?, ?, ?, ?)
                `).run(item.material_id, shipment.warehouse_id, item.quantity, shipment.shipment_no, '发货单取消退回', req.session.user.id);
            }

            db.prepare(`
                UPDATE shipments SET status = 'cancelled', updated_at = datetime('now', 'localtime') WHERE id = ?
            `).run(req.params.id);
        });
        doCancel();
    } else {
        const updates = { status };
        if (status === 'shipped') updates.shipped_at = new Date().toISOString();

        db.prepare(`
            UPDATE shipments SET status = ?,
                shipped_at = CASE WHEN ? = 'shipped' THEN datetime('now', 'localtime') ELSE shipped_at END,
                updated_at = datetime('now', 'localtime')
            WHERE id = ?
        `).run(status, status, req.params.id);
    }

    const statusLabels = { pending: '待确认', confirmed: '已确认', shipped: '已发货', delivered: '已签收', cancelled: '已取消' };

    logOperation({
        userId: req.session.user.id,
        action: 'update',
        resource: 'shipments',
        resourceId: Number(req.params.id),
        detail: `发货单 ${shipment.shipment_no} 状态更新为: ${statusLabels[status]}`,
        ip: req.ip
    });

    res.json({ success: true, message: `状态已更新为: ${statusLabels[status]}` });
});

module.exports = router;
